## -----------------------------------------------------------------------------
library(rtyp)

linebreak()
linebreak(justify = TRUE)
linebreak(any_other_args = TRUE) # this works!


## -----------------------------------------------------------------------------
library(rtyp)

linebreak() |> is_valid_typst()
linebreak(justify = TRUE) |> is_valid_typst()
linebreak(any_other_args = TRUE) |> is_valid_typst()

