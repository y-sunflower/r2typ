## -----------------------------------------------------------------------------
library(rtyp)


## -----------------------------------------------------------------------------
#| eval: false
# typst_code <- c("= Hello World", "This is a Typst document.")
# output_file <- typst_write(typst_code)


## -----------------------------------------------------------------------------
#| eval: false
# typst_compile(output_file)


## -----------------------------------------------------------------------------
#| eval: false
# typst_code <- c("= Hello World", "This is a Typst document.")
# output_file <- typst_write(typst_code, "here.typ")
# typst_compile(output_file, "report.pdf")

